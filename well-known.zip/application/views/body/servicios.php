<section id="cabecera">
    <div class="container">
        <h1>Servicios</h1>
    </div>
</section>
<section id="contenido">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="servicios">
                 
                  <h4>Equipos en ace<az>ro inoxidables</az></h4>
                  <p>Somos fabricantes de equipos de refrigeración y calefacción, como exhibidoras refrigeradas, equipos de panificación, mesas de acero inoxidable, cocinas etc.</p>
                  <div class="gallery">
                  	<a href="img/acero-inoxidable/img1-grande.jpg" data-lightbox="mygallery"><img src="img/acero-inoxidable/img1.jpg" style="float:left;    margin-bottom: 15px;"></a>
                    <a href="img/acero-inoxidable/img2-grande.jpg" data-lightbox="mygallery"><img src="img/acero-inoxidable/img2.jpg" style="float:left;     margin-bottom: 15px; margin-left: 10px"></a>
					<a href="img/acero-inoxidable/img3-grande.jpg" data-lightbox="mygallery"><img src="img/acero-inoxidable/img3.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/acero-inoxidable/img4-grande.jpg" data-lightbox="mygallery" ><img src="img/acero-inoxidable/img4.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/acero-inoxidable/img5-grande.jpg" data-lightbox="mygallery"> <img src="img/acero-inoxidable/img5.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                <hr>
                  </div>
                  
                  
                  <!-- <div class="gallery">
                  	<a href="img/exhibidoras/EXHIBIDORA.png" data-lightbox="mygallery"><img src="img/exhibidoras/EXHIBIDORA.png" style="float:left;    margin-bottom: 15px;"></a>
                    <a href="img/exhibidoras/EXHIBIDORA-VERDE.png" data-lightbox="mygallery"><img src="img/exhibidoras/EXHIBIDORA-VERDE.png" style="float:left;     margin-bottom: 15px; margin-left: 10px"></a>
					<a href="img/exhibidoras/PANERA.png" data-lightbox="mygallery"><img src="img/exhibidoras/PANERA.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/exhibidoras/REINA.png" data-lightbox="mygallery" ><img src="img/exhibidoras/REINA.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/exhibidoras/EXHIBIDORA-02.png" data-lightbox="mygallery"> <img src="img/exhibidoras/EXHIBIDORA-02.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                
                  </div>-->
                  
				<div class="clearfix"></div>
					<br>
					<h4>Ver Catalogo</h4>
					<p>Fabricación y montaje de estructuras metálicas. Carpintería metálica.</p>
					<hr>
					<div class="gallery">
                    	<a href="img/catalogos_nov/000.png" data-lightbox="mygallery"><img src="img/catalogos_nov/000.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/001.png" data-lightbox="mygallery"><img src="img/catalogos_nov/001.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/002.png" data-lightbox="mygallery"><img src="img/catalogos_nov/002.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/003.png" data-lightbox="mygallery"><img src="img/catalogos_nov/003.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/004.png" data-lightbox="mygallery"><img src="img/catalogos_nov/004.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/005.png" data-lightbox="mygallery"><img src="img/catalogos_nov/005.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/006.png" data-lightbox="mygallery"><img src="img/catalogos_nov/006.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/007.png" data-lightbox="mygallery"><img src="img/catalogos_nov/007.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	<a href="img/catalogos_nov/008.png" data-lightbox="mygallery"><img src="img/catalogos_nov/008.png" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    	
                    	
                    	<div id="qrcode">
                        <a href="https://www.codigos-qr.com/qr/php/qr_img.php?d=https%3A%2F%2Finversionesgomcar.com%2Farchivos%2Fcatalogo_gomcar.pdf&s=6&e=m" data-lightbox="mygallery"> <img src="https://www.codigos-qr.com/qr/php/qr_img.php?d=https%3A%2F%2Finversionesgomcar.com%2Farchivos%2Fcatalogo_gomcar.pdf&s=6&e=m" alt="Catalogo Gomcar" style="float:left;    margin-bottom: 15px;"/>Ver catálogo</a> 
                        <br/>
                        <!--<a href="https://www.codigos-qr.com/en/qr-code-generator/" target="_blank" id"qrgenerator">Ver Catálogo</a>-->
                        </div>
                    
                    </div>
                    
				<!--<h4>Estructuras <az>Metálicas</az></h4>
                    <p>Fabricación y montaje de estructuras metálicas. Carpintería metálica.</p>
                  
                   <div class="gallery">
                  	<a href="img/estructuras-metalicas/img6-grande.jpg" data-lightbox="mygallery"><img src="img/estructuras-metalicas/img1.jpg" style="float:left;    margin-bottom: 15px;"></a>
                    <a href="img/estructuras-metalicas/img7-grande.jpg" data-lightbox="mygallery"><img src="img/estructuras-metalicas/img2.jpg" style="float:left;     margin-bottom: 15px; margin-left: 10px"></a>
					<a href="img/estructuras-metalicas/img8-grande.jpg" data-lightbox="mygallery"><img src="img/estructuras-metalicas/img3.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/estructuras-metalicas/img9-grande.jpg" data-lightbox="mygallery"><img src="img/estructuras-metalicas/img4.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/estructuras-metalicas/img10-grande.jpg" data-lightbox="mygallery"> <img src="img/estructuras-metalicas/img5.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                
                  </div>-->
                   
					<div class="clearfix"></div>
                    <h4>Construcción y <az>obras civiles</az></h4>
                    <p>Contratistas generales, proyectos inmobiliarios, drywall y techos acústicos, gerencia de proyectos, ingeniería y construcción, Viviendas, edificios completos.<br>Construimos con la más alta calidad y eficiencia.</p>
                    <hr>
                    <div class="gallery">
                  	<a href="img/construccion-y-obras-civiles/img11-grande.jpg" data-lightbox="mygallery"><img src="img/construccion-y-obras-civiles/img1.jpg" style="float:left;    margin-bottom: 15px;"></a>
                    <a href="img/construccion-y-obras-civiles/img12-grande.jpg" data-lightbox="mygallery"><img src="img/construccion-y-obras-civiles/img2.jpg" style="float:left;     margin-bottom: 15px; margin-left: 10px"></a>
					<a href="img/construccion-y-obras-civiles/img13-grande.jpg" data-lightbox="mygallery"><img src="img/construccion-y-obras-civiles/img3.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/construccion-y-obras-civiles/img14-grande.jpg" data-lightbox="mygallery"><img src="img/construccion-y-obras-civiles/img4.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/construccion-y-obras-civiles/img15-grande.jpg" data-lightbox="mygallery"> <img src="img/construccion-y-obras-civiles/img5.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                
                  </div>
                  
					
				  <div class="clearfix"></div>
				  <br>	
                    <h4>Alquiler de equipos y <az>unidades de transporte</az></h4>
                    <p>Camionetas TOYOTA Hilux 4x4, para transporte y carga.</p>
                    
                    <div class="gallery">
                  	<a href="img/Alquiler-equipos-transporte-carga/img16-grande.jpg" data-lightbox="mygallery"><img src="img/Alquiler-equipos-transporte-carga/img1.jpg" style="float:left;    margin-bottom: 15px;"></a>
                    <a href="img/Alquiler-equipos-transporte-carga/img17-grande.jpg" data-lightbox="mygallery"><img src="img/Alquiler-equipos-transporte-carga/img2.jpg" style="float:left;     margin-bottom: 15px; margin-left: 10px"></a>
					<a href="img/Alquiler-equipos-transporte-carga/img18-grande.jpg" data-lightbox="mygallery"><img src="img/Alquiler-equipos-transporte-carga/img3.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/Alquiler-equipos-transporte-carga/img19-grande.jpg" data-lightbox="mygallery"><img src="img/Alquiler-equipos-transporte-carga/img4.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                    <a href="img/Alquiler-equipos-transporte-carga/img20-grande.jpg" data-lightbox="mygallery"> <img src="img/Alquiler-equipos-transporte-carga/img5.jpg" style="float:left;    margin-bottom: 15px; margin-left: 10px"></a>
                
                  </div>
					
			  </div>
                     </div>
               </div>
           
            
             </div>
    </div>
</section>